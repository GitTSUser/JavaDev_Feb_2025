package com.ford.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class ClientApp {

    public static void main(String[] args) {

        ApplicationContext applicationContext=new FileSystemXmlApplicationContext("src/main/resources/beanConfig.xml");
        //Employee employee=applicationContext.getBean("emp",Employee.class);
        //System.out.println(employee);
        //Project project=applicationContext.getBean("proj", Project.class);

        //System.out.println(project.getId()+" "+project.getName()+" "+project.getDescription());

        Employee employee=applicationContext.getBean("emp",Employee.class);

        System.out.println(employee.getId()+" "+employee.getName()+" "+employee.getSalary());

        Project project=employee.getProject();

        System.out.println(project.getId()+" "+project.getName()+" "+project.getDescription());

        System.out.println("---Certifications---");
        employee.getCertifications().forEach(System.out::println);

        System.out.println("---Accounts---");
        employee.getAccounts().forEach(System.out::println);

    }
}
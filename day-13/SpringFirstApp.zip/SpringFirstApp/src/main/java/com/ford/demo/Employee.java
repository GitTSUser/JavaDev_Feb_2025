package com.ford.demo;

import java.util.List;
import java.util.Set;

public class Employee {

    private int id;
    private String name;
    private double salary;
    private String role;
    private Project project;

    private List<String> certifications;

    private Set<Account> accounts;

    public Set<Account> getAccounts() {
        return accounts;
    }

    public void setAccounts(Set<Account> accounts) {
        this.accounts = accounts;
    }

    public List<String> getCertifications() {
        return certifications;
    }

    public void setCertifications(List<String> certifications) {
        this.certifications = certifications;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public Employee(){
        System.out.println("Employee Constructor called");
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        System.out.println("setId: "+id+" is called");
        this.id = id;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        System.out.println("setSalary: "+salary+" is called");
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        System.out.println("setName: "+name+" is called");
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        System.out.println("setRole: "+role+" is called");
        this.role = role;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", salary=" + salary +
                ", role='" + role + '\'' +
                '}';
    }
}

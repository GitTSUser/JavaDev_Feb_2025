package com.ford.demo;

public class Project {

    private int id;
    private String name;
    private String description;

    public Project(int id, String name, String description) {
        System.out.println("Project constructor called");
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }
}

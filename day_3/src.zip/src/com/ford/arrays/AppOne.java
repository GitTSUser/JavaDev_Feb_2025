//program to work with arrays
package com.ford.arrays;

import java.util.Arrays;

public class AppOne {

	private static String cities[];

	static {
		cities = new String[] { "Chennai", "Mumbai" };
	}

	public void addCity(String city) {
		// create a new_array with old_array+1 size

		String newCities[] = Arrays.copyOf(cities, cities.length + 1);
		newCities[newCities.length - 1] = city;
		cities = newCities;
		printAllCities();

	}

	public boolean searchCity(String city) {

		// search for the given city in array, if success return true otherwise return
		// false

		for (int j = 0; j < cities.length; j++) {
			if (cities[j].equals(city)) {
				return true;
			}
		}

		return false;
	}

	public boolean deleteCity(String city) {

		// findout the given city is present in array or not
		if (searchCity(city)) {

			return true;
		}

		return false;
	}

	public void replaceCity(String city, String replaceWithMe) {

		// search for the given city and if found, just replace it with another city
		// given

	}

	public void printAllCities() {

		// print all cities using for or while loop

		for (int i = 0; i < cities.length; i++) {
			System.out.println("city is:" + cities[i]);

		}
		System.out.println("---------------------------");

	}

	public static void main(String[] args) {

		AppOne obj = new AppOne();
		obj.addCity("Kancheepuram");
		obj.addCity("Blore");
		obj.addCity("Kanpur");

	}

}

//program to print the output msg
package com.ford.basics;

public class AppOne {

	public static void main(String[] args) {

		int x = 100;
		int y = 200;

		System.out.println(x + y); // int+int ---> int
		System.out.println("sum of x,y is:" + (x + y)); // string+int--> string +int --> string

	}

}

package com.ford.basics;

class Countries {
	public static void india() {
		System.out.println("in India");
		lanka();
	}

	public static void usa() {
		india();
		System.out.println("in Usa");
	}

	public static void uk() {
		System.out.println("in UK");
	}

	public static void lanka() {
		uk();
		System.out.println("in SriLanka");
	}
}

class NSCountries {
	public void india() {
		System.out.println("in India");
		lanka();
	}

	public void usa() {
		india();
		System.out.println("in Usa");
	}

	public static void uk() {
		System.out.println("in UK");
	}

	public void lanka() {
		uk(); 
		System.out.println("in SriLanka");
	}
}

public class AppThree {

	public static void main(String[] args) {
		System.out.println("begins in main");
//		Countries.usa();
		NSCountries obj=new NSCountries();
		obj.usa();
		System.out.println("ends in main");
	}
}

//program to find out the average of  salaries of N employees
package com.ford.basics;

public class AppTwo {

	private static double averageOfEmploySalaries(double[] salaries) {

		double sum = 0.0;
		for (int i = 0; i < salaries.length; i++) {
			sum = sum + salaries[i];
		}

		return sum / salaries.length;
	}

	public static void main(String[] args) {
		
		double[] empSalaries = { 4500.25, 5600.25, 7850.25, 9650.25 };

		double avg = averageOfEmploySalaries(empSalaries);
		System.out.println("salary average is:" + avg);
	}
}
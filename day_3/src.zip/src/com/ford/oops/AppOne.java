package com.ford.oops;

import java.time.LocalDate;

class Employ {

	int id;
	String name;
	double salary;
	String email;
	String phone;
	LocalDate dob;
	char gender;

}

public class AppOne {

	public static void main(String[] args) {

		Employ emp = new Employ();
		
		System.out.println(emp.id+" "+emp.name+" "+emp.salary);
		System.out.println(emp.email+" "+emp.phone+" "+emp.dob);

		emp.id=1234;
		emp.name="arul";
		emp.salary=4560.25;
		emp.email="arul@yahoo.com";
		emp.phone="044-2564856";
		emp.dob=LocalDate.of(2002, 11, 22);
		emp.gender='M';
		
		System.out.println(emp.id+" "+emp.name+" "+emp.salary);
		System.out.println(emp.email+" "+emp.phone+" "+emp.dob);

		Employ emp2=new Employ();
		
		emp2.id=1235;
		
		
		
	}

}

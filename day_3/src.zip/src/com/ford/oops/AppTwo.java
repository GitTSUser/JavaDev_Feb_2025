//program to demonstrate constructor overloading and constructor chaining by the use of this keyword

package com.ford.oops;

import java.util.Arrays;

class Developer {

	int id;
	String name;
	double salary;
	String email;
	String company;
	String phone;
	String projects[];

	public Developer() {

	}

	public Developer(int id) {
		this(); // invokes the current class constructor
		this.id = id;
	}

	public Developer(int id, String name) {
		// this.id = id;
		this(id);
		this.name = name;
	}

	public Developer(int id, String name, double salary) {
//		this.id = id;
//		this.name = name;
		this(id, name);
		this.salary = salary;
	}

	public Developer(int id, String name, double salary, String email) {
//		this.id = id;
//		this.name = name;
//		this.salary = salary;
		this(id, name, salary);
		this.email = email;
	}

	public Developer(int id, String name, double salary, String email, String company) {
//		this.id = id;
//		this.name = name;
//		this.salary = salary;
//		this.email = email;
		this(id, name, salary, email);
		this.company = company;
	}

	public Developer(int id, String name, double salary, String email, String company, String phone) {
//		this.id = id;
//		this.name = name;
//		this.salary = salary;
//		this.email = email;
//		this.company = company;
		this(id, name, salary, email, company);
		this.phone = phone;
	}

	public Developer(int id, String name, double salary, String email, String company, String phone,
			String projects[]) {
//		this.id = id;
//		this.name = name;
//		this.salary = salary;
//		this.email = email;
//		this.company = company;
//		this.phone = phone;
		this(id, name, salary, email, company, phone);
		this.projects = projects;
	}

	public void employInfo() {

		System.out.println("employ id:" + this.id);
		System.out.println("employ name:" + this.name);
		System.out.println("employ salary:" + this.salary);
		System.out.println("employ email:" + this.email);
		System.out.println("employ company:" + this.company);
		System.out.println("employ phone:" + this.phone);
		System.out.println("employ projects:" + Arrays.toString(this.projects));
	}

}

public class AppTwo {

	public static void main(String[] args) {
		String projects[] = { "BMS", "CMS", "BCMS" };
		Developer dev1 = new Developer(1234, "vishal", 25660.25, "vishal@yahoo.com", "FORD", "044-257585", projects);
		dev1.employInfo();
	}
}
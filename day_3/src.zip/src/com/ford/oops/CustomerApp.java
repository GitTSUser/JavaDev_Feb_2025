//program  to perform banking txns like withdraw, deposit, transfer etc

package com.ford.oops;

class BankAccount {

	private long accountNo;
	private String accountHolder;
	private double accountBalance;
	private String accountType;

	public BankAccount() {
	}

	public BankAccount(long accountNo) {
		this();
		this.accountNo = accountNo;
	}

	public BankAccount(long accountNo, String accountHolder) {
		this(accountNo);
		this.accountHolder = accountHolder;
	}

	public BankAccount(long accountNo, String accountHolder, double accountBalance) {
		this(accountNo, accountHolder);
		this.accountBalance = accountBalance;
	}

	public BankAccount(long accountNo, String accountHolder, double accountBalance, String accountType) {
		this(accountNo, accountHolder, accountBalance);
		this.accountType = accountType;
	}

	public void deposit(long accountNo, double amountToDeposit) {

		System.out.println("before deposit, balance is:" + this.getAccountBalance());

		this.accountBalance = this.accountBalance + amountToDeposit;
		System.out.println("account is deposited with amount:" + amountToDeposit);
		System.out.println("after deposit, balance is:" + this.getAccountBalance());
	}

	public void withdraw(long accountNo, double amountToWithdraw) {
		System.out.println("before withdraw, balance is:" + this.getAccountBalance());
		if (this.accountBalance > amountToWithdraw) {
			this.accountBalance = this.accountBalance - amountToWithdraw;
			System.out.println("account is debited with amount:" + amountToWithdraw);
		} else {
			System.out.println("Insufficient funds!");
		}
		System.out.println("after withdraw, balance is:" + this.getAccountBalance());
	}

	public void transfer(long fromAccountNo, long toAccountNo, double amountToTransfer) {

		System.out.println("before transfer, balance is:" + this.getAccountBalance());
		if (this.accountBalance > amountToTransfer) {
			this.accountBalance = this.accountBalance - amountToTransfer;
			System.out.println("amount :" + amountToTransfer + " is transfered to account:" + toAccountNo);
		} else {
			System.out.println("Insufficient funds to transfer!");
		}
		System.out.println("after transfer, balance is:" + this.getAccountBalance());
	}

	public double getAccountBalance() {
		return this.accountBalance;
	}

}

public class CustomerApp {

	public static void main(String[] args) {

		BankAccount bankAccount1 = new BankAccount(123456789, "Sachin", 4000.25, "savings");

		bankAccount1.deposit(123456789, 5000.25);
		System.out.println("--------------------------------");
		bankAccount1.withdraw(123456789, 15000.00);
		System.out.println("--------------------------------");
		bankAccount1.transfer(123456789, 223456789, 25000.25);

	}
}
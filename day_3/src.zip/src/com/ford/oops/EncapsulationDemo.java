//program to demonstrate encapsulation implementation

package com.ford.oops;

class Account {

	private long accountNo;
	private String accountType;
	private String accountHolder;
	private double accountBalance;
	private int age;

	public void setAccountNo(long accountNo) {
		if (accountNo < 0) {
			System.out.println("negative accountNo is not allowd");
			throw new IllegalArgumentException();
		}
		this.accountNo = accountNo;
	}

	public void setAccountType(String accountType) {
		if (accountType.equals("savings") || accountType.equals("current")) {

			this.accountType = accountType;
		} else {
			System.out.println("invalid account type");
		}

	}

	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}

	public void setAccountBalance(double accountBalance) {
		if (accountBalance < 1000) {
			System.out.println("invalid amount");
			throw new IllegalArgumentException();

		}
		this.accountBalance = accountBalance;
	}

	public void setAge(int age) {

		if (age > 18 && age <= 100) {
			this.age = age;
		} else {
			System.out.println("invalid age");
			throw new IllegalArgumentException();
		}
	}

	public void accountInfo() {
		System.out.println(accountNo + " " + accountType + " " + accountHolder + " " + accountBalance + " " + age);
	}

	public double getAccountBalance() {
		return this.accountBalance;
	}

	public String getAccountHolder() {
		return this.accountHolder;
	}
}

public class EncapsulationDemo {

	public static void main(String[] args) {

		Account account = new Account();
		account.setAccountNo(456236);
		account.setAccountHolder("varun");
		account.setAccountBalance(45000.25);
		account.setAge(20);
		account.setAccountType("savings");

		System.out.println(account.getAccountHolder());
		System.out.println(account.getAccountBalance());
	}
}
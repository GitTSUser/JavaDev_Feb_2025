package com.ford.oops;

class Bike {

	private int plateNo;
	private static String brand;
	private String type;
	private double price;
	private String owner;

	static {
		brand = "FORD";
	}

	{ // non-static block
		this.plateNo = (int) Math.abs(Math.random() * 1234);

		if (this.plateNo % 2 == 0) {
			this.type = "GEAR";
		} else {
			this.type = "AUTO";
		}

		if (this.type.equals("GEAR")) {
			this.price = 86000.25;
		} else {
			this.price = 120000.25;
		}
	}

	public Bike(String owner) {
		this.owner = owner;
	}

	public int getPlateNo() {
		return this.plateNo;
	}

	public String getBrand() {
		return brand;
	}

	public String getType() {
		return this.type;
	}

	public double getPrice() {
		return this.price;
	}

	public String getOwner() {
		return this.owner;
	}

}

public class FordBikes {

	public static Bike[] getBikesForCustomers(String customers[]) {

		Bike[] bikes = new Bike[customers.length];
		for (int i = 0; i < customers.length; i++) {

			bikes[i] = new Bike(customers[i]);

		}

		return bikes;
	}

	public static void main(String[] args) {

		String customers[] = { "Arun", "Varun", "Tarun", "Charun", "Karan" };
		Bike bikes[] = getBikesForCustomers(customers);

		for(int i=0;i<bikes.length;i++) {
			Bike b=bikes[i];
			System.out.println(b.getPlateNo()+" "+b.getBrand()+" "+b.getOwner()+" "+b.getType()+" "+b.getPrice());
		}
		
	}
}

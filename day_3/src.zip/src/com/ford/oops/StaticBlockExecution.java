package com.ford.oops;

public class StaticBlockExecution {

	static {
		System.out.println("in first static block");
	}

	{ // non-static block
		System.out.println("in non-static block");
	}

	public static void main(String[] args) {

		System.out.println("in main method");

		StaticBlockExecution obj = new StaticBlockExecution();
		StaticBlockExecution obj2 = new StaticBlockExecution();
		StaticBlockExecution obj3 = new StaticBlockExecution();
	}

	static {
		System.out.println("in second static block");
	}
}

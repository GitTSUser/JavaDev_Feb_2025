//program to demonstrate the use of static variable and block
package com.ford.oops;

public class StaticMembersDemo {

	static class Student {

		private int id;
		private String name;
		private String course;
		private static String college;
		private static String city;

		static {
			System.out.println("in static block");
			college = "VIT";
		}

		public Student(int id, String name, String course) {
			this.id = id;
			this.name = name;
			this.course = course;
		}

		public void studentInfo() {
			System.out.println("id is:" + id);
			System.out.println("name is:" + name);
			System.out.println("course is:" + course);
			System.out.println("college is:" + college);
			System.out.println("city is:" + city);
			System.out.println("-----------------------");
		}

		static {
			System.out.println("in city static block");
			city = "CHENNAI";
		}

	}

	public static void main(String[] args) {

		Student s1 = new Student(123, "mohan", "CSE");
		Student s2 = new Student(124, "sohan", "ECE");
		Student s3 = new Student(125, "rohan", "IT");

		s1.studentInfo();
		s2.studentInfo();
		s3.studentInfo();
	}

}

package com.ford.oops;

class Student {
	private int id;
	private String name;
	private String course;
	private double fee;
	private static int student_id = 1001;

	public Student(String name, String course, double fee) {
		this.id = student_id++;
		this.name = name;
		this.course = course;
		this.fee = fee;
	}

	public void studentInfo() {
		System.out.println(id + " " + name + " " + course + " " + fee);

	}

}

public class UseOfStaticVariable {

	public static void main(String[] args) {

		Student s1 = new Student("arun", "CSE", 2500.25);
		Student s2 = new Student("varun", "ECE", 3500.25);
		Student s3 = new Student("tarun", "EEE", 4500.25);
		Student s4 = new Student("karun", "IT", 5500.25);

		s1.studentInfo();
		s2.studentInfo();
		s3.studentInfo();
		s4.studentInfo();

	}
}
